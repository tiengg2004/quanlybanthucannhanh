
package ENTITY;

import UTILS.XDate;
import java.util.Date;


public class NhanVien {
    private String MaNV;
    private String TenNV;
    private boolean GioiTinh;
    private String  Email;
    private String Matkhau;
    private String DiaChi;
    private String DienThoai;
    private String HinhAnh;
    private Date NgaySinh = XDate.addDays(new Date(), -365*20);
    private boolean Vaitro = false ;

    public NhanVien() {
    }

    public NhanVien(String MaNV, String TenNV, boolean GioiTinh, String Email, String Matkhau, String DiaChi, String DienThoai, String HinhAnh, boolean Vaitro) {
        this.MaNV = MaNV;
        this.TenNV = TenNV;
        this.GioiTinh = GioiTinh;
        this.Email = Email;
        this.Matkhau = Matkhau;
        this.DiaChi = DiaChi;
        this.DienThoai = DienThoai;
        this.HinhAnh = HinhAnh;
        this.Vaitro = Vaitro;
    }
 @Override
    public String toString() {
        return this.TenNV;
    }
    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public String getTenNV() {
        return TenNV;
    }

    public void setTenNV(String TenNV) {
        this.TenNV = TenNV;
    }

    public boolean getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(boolean GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getMatkhau() {
        return Matkhau;
    }

    public void setMatkhau(String Matkhau) {
        this.Matkhau = Matkhau;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public String getDienThoai() {
        return DienThoai;
    }

    public void setDienThoai(String DienThoai) {
        this.DienThoai = DienThoai;
    }

    public String getHinhAnh() {
        return HinhAnh;
    }

    public void setHinhAnh(String HinhAnh) {
        this.HinhAnh = HinhAnh;
    }

    public Date getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(Date NgaySinh) {
        this.NgaySinh = NgaySinh;
    }

    public boolean getVaitro() {
        return Vaitro;
    }

    public void setVaitro(boolean Vaitro) {
        this.Vaitro = Vaitro;
    }

  

    
            
}
