
package ENTITY;


public class SanPham {
    private String MaSP;
    private String TenSP;
    private String Gia;
    private int SoLuong;
    private String MaLoai;
    private String LoaiSP;
    private String HinhAnh;

    public SanPham(String maSP, String tenSP, double gia, int soLuong) {
    }

    public SanPham() {
    }

    public SanPham(String MaSP, String TenSP, String Gia, int SoLuong, String MaLoai, String LoaiSP, String HinhAnh) {
        this.MaSP = MaSP;
        this.TenSP = TenSP;
        this.Gia = Gia;
        this.SoLuong = SoLuong;
        this.MaLoai = MaLoai;
        this.LoaiSP = LoaiSP;
        this.HinhAnh = HinhAnh;
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String MaSP) {
        this.MaSP = MaSP;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String TenSP) {
        this.TenSP = TenSP;
    }

    public String getGia() {
        return Gia;
    }

    public void setGia(String Gia) {
        this.Gia = Gia;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String MaLoai) {
        this.MaLoai = MaLoai;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }

    public String getLoaiSP() {
        return LoaiSP;
    }

    public void setLoaiSP(String LoaiSP) {
        this.LoaiSP = LoaiSP;
    }

    public String getHinhAnh() {
        return HinhAnh;
    }

    public void setHinhAnh(String HinhAnh) {
        this.HinhAnh = HinhAnh;
    }
    
    
    
    
}

