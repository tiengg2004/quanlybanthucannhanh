
package ENTITY;

import UTILS.XDate;
import java.util.Date;


public class HoaDon {
    private String MaNV;
    private String MaKH;
    private int SoLuong;
    private String MaHD;
    private String TenSP;
    private String Gia;
    private String MaSP;
    private boolean TrangThai;
    private Date NgayTao = XDate.addDays(new Date(), -365*20);;

    public HoaDon() {
    }

    public HoaDon(String MaNV, String MaKH,int SoLuong, String MaHD, String TenSP, String Gia, String MaSP, boolean TrangThai) {
        this.MaNV = MaNV;
        this.MaKH = MaKH;
        this.SoLuong = SoLuong;
        this.MaHD = MaHD;
        this.TenSP = TenSP;
        this.Gia = Gia;
        this.MaSP = MaSP;
        this.TrangThai = TrangThai;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public String getMaKH() {
        return MaKH;
    }

    public void setMaKH(String MaKH) {
        this.MaKH = MaKH;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }

    public String getMaHD() {
        return MaHD;
    }

    public void setMaHD(String MaHD) {
        this.MaHD = MaHD;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String TenSP) {
        this.TenSP = TenSP;
    }

    public String getGia() {
        return Gia;
    }

    public void setGia(String Gia) {
        this.Gia = Gia;
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String MaSP) {
        this.MaSP = MaSP;
    }

    public boolean getTrangThai() {
        return TrangThai;
    }

    public void setTrangThai(boolean TrangThai) {
        this.TrangThai = TrangThai;
    }

    public Date getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(Date NgayTao) {
        this.NgayTao = NgayTao;
    }
   
    
}
