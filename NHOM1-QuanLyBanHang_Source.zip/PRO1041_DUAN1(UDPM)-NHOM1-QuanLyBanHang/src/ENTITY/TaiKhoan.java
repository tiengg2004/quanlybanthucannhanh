
package ENTITY;


public class TaiKhoan {
    private String MaNV;
    private String matkhau;
    private boolean Vaitro;

    public TaiKhoan() {
    }

    public TaiKhoan(String MaNV, String matkhau, boolean Vatro) {
        this.MaNV = MaNV;
        this.matkhau = matkhau;
        this.Vaitro = Vaitro;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public String getMatkhau() {
        return matkhau;
    }

    public void setMatkhau(String matkhau) {
        this.matkhau = matkhau;
    }

    public boolean getVaitro() {
        return Vaitro;
    }

    public void setVatro(boolean Vaitro) {
        this.Vaitro = Vaitro;
    }
    
    
}
