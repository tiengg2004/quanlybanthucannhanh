
package DAO;



import ENTITY.HoaDon;
import UTILS.JdbcHelper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class HoaDonDAO extends QuanLyBanHangDAO<HoaDon, String>{

    final String INSERT_SQL = "INSERT INTO HoaDon (MaHD, NgayTao,  MaKH, MaNV) VALUES (?, ?, ?, ?)";
    final String UPDATE_SQL = "UPDATE HoaDon SET  NgayTao=? , MaKH=?, MaNV=?   WHERE MaHD=?";
    final String DELETE_SQL = "DELETE FROM HoaDon WHERE MaHD=?";
//   
    final String SELECT_ALL_SQL = "SELECT *  FROM HoaDon ";
    
    final String SELECT_BY_ID_SQL = "SELECT * FROM HoaDon WHERE MaHD=?";
    
    @Override
    public void insert(HoaDon entity) {
        JdbcHelper.update(INSERT_SQL,
                entity.getMaHD(),
                entity.getNgayTao(),
                entity.getMaKH(),
                entity.getMaNV()
                
                
                );
    }

    @Override
    public void update(HoaDon entity) {
        JdbcHelper.update(UPDATE_SQL,
                entity.getNgayTao(),
                entity.getMaKH(),
                entity.getMaNV(),
                entity.getMaHD()
                );
    }

    @Override
    public void delete(String id ) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<HoaDon> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public HoaDon selectById(String id) {
        List<HoaDon> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<HoaDon> selectBySql(String sql, Object... args) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while(rs.next()){
                HoaDon entity = new HoaDon();
                entity.setMaHD(rs.getString("MaHD"));
                entity.setMaKH(rs.getString("MaKH"));
                entity.setMaNV(rs.getString("MaNV"));
//                entity.setTrangThai(rs.getBoolean("TrangThai"));
                entity.setNgayTao(rs.getDate("NgayTao"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}