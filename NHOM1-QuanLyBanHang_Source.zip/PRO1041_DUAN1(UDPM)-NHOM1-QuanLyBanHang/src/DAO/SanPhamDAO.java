   /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import ENTITY.SanPham;
import UTILS.JdbcHelper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class SanPhamDAO extends QuanLyBanHangDAO<SanPham, String>{

    final String INSERT_SQL = "INSERT INTO SanPham (MaSP, TenSP, Gia, SoLuong, MaLoai, HinhAnh) VALUES (?, ?, ?, ?, ?, ?)";
    final String UPDATE_SQL = "UPDATE SanPham SET TenSP=?, Gia=?, SoLuong=?, MaLoai=?, Hinhanh=? WHERE MaSP=?";
    final String DELETE_SQL = "DELETE FROM SanPham WHERE MaSP=?";
    final String SELECT_ALL_SQL = "SELECT MaSP, TenSP, Gia, SoLuong, TenLoai, HinhAnh FROM SanPham SP JOIN LoaiSanPham LSP on LSP.MaLoai = SP.MaLoai  ";
    final String SELECT_BY_ID_SQL = "SELECT MaSP, TenSP, Gia, SoLuong, TenLoai, HinhAnh FROM SanPham SP JOIN LoaiSanPham LSP on LSP.MaLoai = SP.MaLoai WHERE MaSP=?";
   
    @Override
    public void insert(SanPham entity) {
        JdbcHelper.update(INSERT_SQL,
            entity.getMaSP(),
            entity.getTenSP(),
            entity.getGia(),
            entity.getSoLuong(),
            entity.getMaLoai(),
            entity.getHinhAnh()
                );
    }

    @Override
    public void update(SanPham entity) {
        JdbcHelper.update(UPDATE_SQL,
            entity.getTenSP(),
            entity.getGia(),
            entity.getSoLuong(),
            entity.getMaLoai(),
            entity.getHinhAnh(),
            entity.getMaSP());
    }

    @Override
    public void delete(String id) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<SanPham> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public SanPham selectById(String id) {
        List<SanPham> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<SanPham> selectBySql(String sql, Object... args) {
        List<SanPham> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while(rs.next()){
                SanPham entity = new SanPham();
                entity.setMaSP(rs.getString("MaSP"));
                entity.setTenSP(rs.getString("TenSP"));
                entity.setGia(rs.getString("Gia"));
                entity.setSoLuong(rs.getInt("SoLuong"));
                entity.setLoaiSP(rs.getString("TenLoai"));
                entity.setHinhAnh(rs.getString("HinhAnh"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}


