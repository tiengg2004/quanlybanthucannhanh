/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import ENTITY.TaiKhoan;
import UTILS.JdbcHelper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class TaiKhoanDAO extends QuanLyBanHangDAO<TaiKhoan, String>{

    final String INSERT_SQL = "INSERT INTO NhanVien (MaNV, MatKhau) VALUES (?, ?)";
    final String UPDATE_SQL = "UPDATE NhanVien SET MatKhau=? WHERE MaNV=?";
    final String DELETE_SQL = "DELETE FROM NhanVien WHERE MaNV=?";
    final String SELECT_ALL_SQL = "SELECT MaNV, MatKhau FROM NhanVien";
    final String SELECT_BY_ID_SQL = "SELECT MaNV, MatKhau FROM NhanVien WHERE MaNV=?";
    @Override
    public void insert(TaiKhoan entity) {
        JdbcHelper.update(INSERT_SQL);
    }

    @Override
    public void update(TaiKhoan entity) {
        JdbcHelper.update(UPDATE_SQL);
    }

    @Override
    public void delete(String id) {
        JdbcHelper.update(UPDATE_SQL, id);
    }

    @Override
    public List<TaiKhoan> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public TaiKhoan selectById(String id) {
        List<TaiKhoan> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<TaiKhoan> selectBySql(String sql, Object... args) {
        List<TaiKhoan> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while(rs.next()){
                TaiKhoan entity = new TaiKhoan();
                entity.setMaNV(rs.getString("MaNV"));
                entity.setMatkhau(rs.getString("MatKhau"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}

