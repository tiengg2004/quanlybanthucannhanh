/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author buian20062004
 *//*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import ENTITY.KhachHang;
import UTILS.JdbcHelper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ENTITY.KhachHang;

/**
 *
 * @author admin
 */
public class KhachHangDAO extends QuanLyBanHangDAO<KhachHang, String>{

    final String INSERT_SQL = "INSERT INTO KhachHang (MaKH, HoTenKH, ,DiaChi, NgaySinh, Email, SDT, GioiTinh, HinhAnh) VALUES (?, ?, ?, ?, ?)";
    final String UPDATE_SQL = "UPDATE KhachHang SET HoTenKH=?, DiaChi=?, Ngaysinh=?, Email=?,  SDT=?,  GioiTinh=?,    Hinhanh=? WHERE MaKH=?";
    final String DELETE_SQL = "DELETE FROM KhachHang WHERE MaKH=?";
    final String SELECT_ALL_SQL = "SELECT * FROM KhachHang";
    final String SELECT_BY_ID_SQL = "SELECT * FROM KhachHang WHERE MaKH=?";
    @Override
    public void insert(KhachHang entity) {
        JdbcHelper.update(INSERT_SQL,
                entity.getMaKH(),
                entity.getTenKH(),
                entity.getDiaChi(),
                entity.getNgaySinh(),
                entity.getEmail(),
                entity.getSDT(),
                entity.getGioiTinh(),
                entity.getHinhAnh()
                );
    }

    @Override
    public void update(KhachHang entity) {
        JdbcHelper.update(UPDATE_SQL,
                entity.getTenKH(),
                entity.getDiaChi(),
                entity.getNgaySinh(),
                entity.getEmail(),
                entity.getSDT(),
                entity.getGioiTinh(),
                entity.getHinhAnh(),
                entity.getMaKH());
    }

    @Override
    public void delete(String id) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<KhachHang> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public KhachHang selectById(String id) {
        List<KhachHang> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<KhachHang> selectBySql(String sql, Object... args) {
        List<KhachHang> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while(rs.next()){
                KhachHang entity = new KhachHang();
                entity.setMaKH(rs.getString("MaKH"));
                entity.setTenKH(rs.getString("HoTenKH"));
                entity.setGioiTinh(rs.getBoolean("GioiTinh"));
                entity.setNgaySinh(rs.getDate("NgaySinh"));
                entity.setEmail(rs.getString("Email"));
                entity.setSDT(rs.getString("SDT"));
                entity.setDiaChi(rs.getString("DiaChi"));
                entity.setHinhAnh(rs.getString("HinhAnh"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}


