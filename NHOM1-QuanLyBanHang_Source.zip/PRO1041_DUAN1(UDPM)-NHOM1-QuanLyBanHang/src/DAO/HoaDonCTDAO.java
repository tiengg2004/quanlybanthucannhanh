
package DAO;



import ENTITY.HoaDon;
import UTILS.JdbcHelper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class HoaDonCTDAO extends QuanLyBanHangDAO<HoaDon, String>{

    final String INSERT_SQL = "INSERT INTO HoaDonChiTiet ( TenSP ,SoLuong, Gia, MaSP, MaHD) VALUES (?, ?, ?, ?, ?)";
    final String UPDATE_SQL = "UPDATE HoaDonChiTiet SET  SoLuong=?   WHERE MaHD=? and MaSP =?";
    final String DELETE_SQL = "DELETE FROM HoaDonChiTiet WHERE MaHD=?";
//   
    final String SELECT_ALL_SQL = "SELECT HDCT.MaHD, HDCT.MaSP , HDCT.TenSP, SP.Gia * HDCT.SoLuong as Gia , HDCT.SoLuong  FROM HoaDonChiTiet HDCT JOIN HoaDon HD ON HDCT.MaHD = HD.MaHD Join SanPham SP ON HDCT.MaSP = SP.MaSP ";
    
    final String SELECT_BY_ID_SQL = "SELECT HDCT.MaHD, HDCT.MaSP , HDCT.TenSP, SP.Gia * HDCT.SoLuong as Gia , HDCT.SoLuong FROM HoaDonChiTiet HDCT JOIN HoaDon HD ON HDCT.MaHD = HD.MaHD Join SanPham SP ON HDCT.MaSP = SP.MaSP WHERE HD.MaHD=?";
    
    @Override
    public void insert(HoaDon entity) {
        JdbcHelper.update(INSERT_SQL,
                entity.getTenSP(),
                entity.getSoLuong(),
                entity.getGia(),
                entity.getMaSP(),
                entity.getMaHD()
                );
    }

    @Override
    public void update(HoaDon entity) {
        JdbcHelper.update(UPDATE_SQL,
                entity.getSoLuong(),
                entity.getGia(),
                entity.getMaHD(),
                entity.getMaSP()
                );
    }

    @Override
    public void delete(String id ) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<HoaDon> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public HoaDon selectById(String id) {
        List<HoaDon> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<HoaDon> selectBySql(String sql, Object... args) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while(rs.next()){
                HoaDon entity = new HoaDon();
                entity.setMaHD(rs.getString("MaHD"));
                entity.setMaSP(rs.getString("MaSP"));
                entity.setTenSP(rs.getString("TenSP"));
                entity.setGia(rs.getString("Gia"));
                entity.setSoLuong(rs.getInt("SoLuong"));
//                entity.setTrangThai(rs.getBoolean("TrangThai"));
//                entity.setNgayTao(rs.getDate("NgayTao"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}