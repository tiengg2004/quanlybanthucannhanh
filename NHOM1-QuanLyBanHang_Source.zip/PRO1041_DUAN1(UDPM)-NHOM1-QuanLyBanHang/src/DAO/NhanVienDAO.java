/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import ENTITY.NhanVien;
import UTILS.JdbcHelper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class NhanVienDAO extends QuanLyBanHangDAO<NhanVien, String>{

    final String INSERT_SQL = "INSERT INTO NhanVien (MaNV, HoTenNV,  Email, SDT, Ngaysinh, VaiTro, Matkhau, HinhAnh, GioiTinh, DiaChi) VALUES \n" +
"(?,?,?,?,?,?,?,?,?,?)";
    final String UPDATE_SQL = "UPDATE NhanVien SET HoTenNV=?,  Email=?, SDT=?, Ngaysinh=?, VaiTro=?, Matkhau=?, HinhAnh=?, GioiTinh=?, DiaChi=? WHERE MaNV=?";
    final String DELETE_SQL = "DELETE FROM NhanVien WHERE MaNV=?";
    final String SELECT_ALL_SQL = "SELECT * FROM NhanVien";
    final String SELECT_BY_ID_SQL = "SELECT * FROM NhanVien WHERE MaNV=?";
    @Override
    public void insert(NhanVien entity) {
        JdbcHelper.update(INSERT_SQL,  
        entity.getMaNV(), 
        entity.getTenNV(), 
        entity.getEmail(), 
        entity.getDienThoai(), 
        entity.getNgaySinh(), 
        entity.getVaitro(), 
        entity.getMatkhau(), 
        entity.getHinhAnh(), 
        entity.getGioiTinh(), 
        entity.getDiaChi()
);
    }

    @Override
    public void update(NhanVien entity) {
        JdbcHelper.update(UPDATE_SQL,
        entity.getTenNV(), 
        entity.getEmail(), 
        entity.getDienThoai(), 
        entity.getNgaySinh(), 
        entity.getVaitro(), 
        entity.getMatkhau(), 
        entity.getHinhAnh(), 
        entity.getGioiTinh(), 
        entity.getDiaChi(),
        entity.getMaNV());
    }

    @Override
    public void delete(String id) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<NhanVien> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public NhanVien selectById(String id) {
        List<NhanVien> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<NhanVien> selectBySql(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while(rs.next()){
                NhanVien entity = new NhanVien();
                entity.setMaNV(rs.getString("MaNV"));
                entity.setTenNV(rs.getString("HoTenNV"));
                entity.setEmail(rs.getString("Email"));
                entity.setDienThoai(rs.getString("SDT"));
                entity.setNgaySinh(rs.getDate("NgaySinh"));
                entity.setVaitro(rs.getBoolean("VaiTro"));
                entity.setMatkhau(rs.getString("MatKhau"));
                entity.setGioiTinh(rs.getBoolean("GioiTinh"));
                entity.setHinhAnh(rs.getString("HinhAnh"));
                entity.setDiaChi(rs.getString("DiaChi"));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}
